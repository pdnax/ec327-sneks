package com.example.myapplication.enums;

public enum TileType {
    Nothing,
    Wall,
    SnakeHead,
    SnakeTail,
    SnakeHead_P1,
    SnakeTail_P1,
    SnakeHead_P2,
    SnakeTail_P2,
    Food,
    Snack
}
