package com.example.myapplication.enums;

public enum GameState {
    Running,
    Lost,
    Lost2,
    Draw,
    Over
}
