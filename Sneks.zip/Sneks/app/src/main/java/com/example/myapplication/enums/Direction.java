package com.example.myapplication.enums;

public enum Direction {
    Up,
    Right,
    Down,
    Left
}
